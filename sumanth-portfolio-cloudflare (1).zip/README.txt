SUMANTH MATURI — PORTFOLIO WEBSITE
Everything needed to put the site online. Nothing else to install.

1. PUT IT LIVE (about two minutes, free)
   a. Unzip this folder.
   b. Go to https://app.netlify.com/drop
   c. Drag the folder "sumanth-portfolio-live" onto the page — the folder that has
      index.html inside it. Not a single file, not an inner folder.
   d. You get a live address straight away. Create a free account to keep it,
      rename it under Site settings, or add your own domain under Domain management.
   Vercel, GitHub Pages and Cloudflare Pages work the same way: upload the folder as is.

2. TURN ON THE CONTACT FORM (one time, 30 seconds)
   The form sends to sumanthmaturi04@gmail.com through FormSubmit.
   a. Open the live site -> Contact -> send yourself a test message.
   b. FormSubmit emails you an "Activate Form" link. Click it.
   c. Done. Every message then arrives in Gmail as a neat table: name, email,
      company, what they need, timeline and the message. Replying goes straight
      back to the sender.
   If FormSubmit is ever unreachable, the form falls back to opening the visitor's
   own email app with the details filled in, so nothing is lost.

3. WHAT'S IN THE FOLDER
   index.html          Home
   Work.dc.html        The story
   Cases.dc.html       Case studies
   About.dc.html       About
   Contact.dc.html     Contact
   Case-*.dc.html      The six case studies
   404.html            Shown if someone hits a wrong link
   support.js          The page engine (menu, product deck, route map, tabs, form)
   responsive.css      Phone / tablet / laptop layout rules
   fonts/              Josefin Sans, bundled so the type never falls back
   Sumanth-Maturi-Resume.pdf   Your resume — the Resume buttons open this
   _blob/              Every image (and a second copy of the resume)
   robots.txt          Lets search engines index the site
   sitemap.xml         Page list for search engines — replace YOUR-SITE-ADDRESS
                       with your real address once you have one
   _redirects          Short links on Netlify: /about, /cases, /contact, /resume ...
   Keep the folder together. The pages look for these files beside them.

4. HOW IT BEHAVES
   1240px and up   Full desktop layout, centred.
   Tablets/small   Reflows to fewer columns, headings shrink, the product deck
   laptops         scales down, the career route swipes sideways.
   Phones          Single column, full-screen menu, bigger tap targets.
   Also handled: keyboard focus rings, reduced-motion preference, printing,
   link previews for LinkedIn/WhatsApp shares, and lazy image loading for speed.

5. LINKS IN THE SITE
   Email      sumanthmaturi04@gmail.com
   Phone      +91 94943 40266
   WhatsApp   wa.me/919494340266
   LinkedIn   linkedin.com/in/sumanth-maturi-b0568623b
   Behance    behance.net/sumanthmaturi1
   Instagram  instagram.com/sumanth_.maturi_
   Resume     opens Sumanth-Maturi-Resume.pdf in a new tab (visitors save it
              from there — a forced download is blocked by browsers when a page
              is opened from a local file, which is why it now opens instead)

6. GOOD TO KNOW
   - View it through the live address. Double-clicking the files won't work.
     To check locally: run "python3 -m http.server" in this folder, then open
     http://localhost:8000
   - Editing the canvas design does not update this copy. Ask me to rebuild it.
